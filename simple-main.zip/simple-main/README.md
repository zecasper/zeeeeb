<h1 align="center">
  SIMPLE CRACK
</h1>
</div>
<p align="center">
  Author <a href="https://www.facebook.com/siti.khatijah.1029">Fall Xavier</a>
</p>
<p align="center">


#### Install script on Termux
```bash
$ pkg update && pkg upgrade
$ pkg install python2
$ pkg install git
$ pip install requests
$ pip2 install requests
$ git clone https://github.com/Fall-Xavier/simple
```
#### Run script
```bash
$ cd simple
$ python2 run.py
```
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Fall-Xavier)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/siti.khatijah.1029)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/ziiro24/) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/6285229323951?text=Asalamualaikum+bang)

#### Donate :

<a href="https://wa.me/6285229323951?text=Saya%20ingin%20donasi%20bang"><img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="alt text" width="80" height="80"></a> &nbsp;&nbsp;

* Notice Me : Please Don't Change Name Author
Thanks For Using My Script
